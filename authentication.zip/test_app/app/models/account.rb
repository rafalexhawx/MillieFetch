class Account < ApplicationRecord
end
