require 'digest';
require 'uri';
require 'net/http';
require 'securerandom';

class AdminController < ApplicationController
  def index
    puts("Admin page has been opened")
    @accounts = Account.all
  end

  def otp
    nonce = SecureRandom.alphanumeric(rand(16..40))
    otp = params['otp']
    #puts("OTP: #{otp}")
    uri = URI("https://api.yubico.com/wsapi/2.0/verify?id=73067&nonce=#{nonce}&otp=" + params['otp'])
    res = Net::HTTP.get_response(uri)
    data = res.body.split()
    parsed = {
      :hash => data[0],
      :time => data[1],
      :otp => data[2],
      :nonce => data[3],
      :status => data[5]
    }
    return render json: parsed
  end
end
