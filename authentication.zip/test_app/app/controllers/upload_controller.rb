class UploadController < ApplicationController
  def view
  end
end
