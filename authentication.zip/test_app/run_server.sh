sudo service postgresql restart
rails server
